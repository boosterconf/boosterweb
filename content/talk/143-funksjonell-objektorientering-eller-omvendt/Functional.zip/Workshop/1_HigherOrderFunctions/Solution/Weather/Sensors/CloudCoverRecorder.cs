﻿using System;
using System.Collections.Generic;

namespace Weather.Sensors
{
    // The Cloud Cover Recorder is an instrument that uses infrared sensors and lasers to scan (part of) the sky
    // to determine the actual cloud cover.

    // Cloud cover is measured in oktas, raging from 0 to 8. One okta corresponds to 1/8 og the sky beeing covered in clouds.
    // So 0 oktas means clear sky, 8 oktas is fully overcast.
    // There is also a level of 9 oktas, meaning that the sky could not be observed because of fog or heavy snowfall.

    public class CloudCoverRecorder : ISensor<int>
    {
        private Dictionary<string, int> cloudCover = new Dictionary<string, int>();

        public Func<string, int> InitSensor(Func<IEnumerable<WeatherData>, Dictionary<string, int>> setup)
        {
            cloudCover = setup(WeatherData.SensorValues);
            return s => cloudCover[s];
        }
    }
}
