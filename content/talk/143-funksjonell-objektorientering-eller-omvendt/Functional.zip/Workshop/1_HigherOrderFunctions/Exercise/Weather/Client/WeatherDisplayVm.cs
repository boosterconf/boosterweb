﻿using Prism.Commands;
using PropertyChanged;
using Weather.Domain;

namespace Weather.Client
{
    [AddINotifyPropertyChangedInterface]
    public class WeatherDisplayVm
    { 
        private WeatherStationService Service = new WeatherStationService();
        public DelegateCommand StartCommand { get; set; }
        public DelegateCommand UpdateCommand { get; set; }
        public Measurements CurrentValues { get; set; }
        public bool ServiceRunning { get; set; }
        public WeatherDisplayVm()
        {
            StartCommand = new DelegateCommand(StartService, () => !ServiceRunning).ObservesProperty(() => ServiceRunning);
            UpdateCommand = new DelegateCommand(() => Update(), () => ServiceRunning).ObservesProperty(() => ServiceRunning);
        }

        private void StartService()
        {
            Service.StartUp();
            Update();
        }

        private void Update()
        {
            CurrentValues = null;
            Service.UpdateReadings();
            UpdateClient();
        }

        private void UpdateClient()
        {
            CurrentValues = Service.CurrentValues;
            ServiceRunning = Service.Running;
        }
    }
}
