﻿using System.Collections.Generic;
using System.Linq;
using Weather.Logging;
using Weather.Sensors;

namespace Weather.Domain
{
    public class WeatherStationService
    {
        public Measurements CurrentValues { get; } = new Measurements();
        private ConnectedSensors Sensors = new ConnectedSensors();
        IEnumerator<string> Timestapms = WeatherData.SensorValues.Select(v=>v.Timestamp).ToList().GetEnumerator();
        DbLogger DbLogger = new DbLogger();
        public bool Running { get; set; } = false;
        public Dictionary<ISensor, ISensorReader> SensorReaders = new Dictionary<ISensor, ISensorReader>();
        public void StartUp()
        {
            Running = true;
            Timestapms.Reset();
            // ToDo: Initiate sensor(s) here
        }
        public void UpdateReadings()
        {
            if (Timestapms.MoveNext()) 
            { 
                ReadSensors(Timestapms.Current);
                DbLogger.LogCurrentValues(CurrentValues);
            }
            else { Running = false; }
        }

        private void ReadSensors(string timestamp)
        {
            CurrentValues.Timestamp = timestamp;
            // ToDo: Get and store sensor value(s)
        }
    }
}
