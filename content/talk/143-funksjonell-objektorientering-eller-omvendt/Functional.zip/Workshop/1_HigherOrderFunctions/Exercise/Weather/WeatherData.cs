﻿using System.Collections.Generic;

namespace Weather
{
    public class WeatherData
    {
        public string Timestamp { get; internal set; }
        public int CloudCover { get; internal set; }
        public double Rainfall { get; internal set; }
        public double Temperature { get; internal set; }
        public int WindSpeed { get; internal set; }
        public string WindDirection { get; internal set; }
        public string Humidity { get; internal set; }
        public static List<WeatherData> SensorValues { get; } = new List<WeatherData>
        {
            {new WeatherData{Timestamp = "08:00", CloudCover=8, Rainfall=2.5, Temperature=278.75, WindSpeed=18, WindDirection="SW", Humidity="65" }},
            {new WeatherData{Timestamp = "09:00", CloudCover=0, Rainfall=0.0, Temperature=275.45, WindSpeed=10, WindDirection="E",  Humidity="ERR" }},
            {new WeatherData{Timestamp = "10:00", CloudCover=4, Rainfall=0.1, Temperature=277.95, WindSpeed=12, WindDirection="E",  Humidity="41" }},
            {new WeatherData{Timestamp = "11:00", CloudCover=1, Rainfall=0.0, Temperature=277.85, WindSpeed= 5, WindDirection="NW", Humidity=null }},
            {new WeatherData{Timestamp = "12:00", CloudCover=7, Rainfall=4.0, Temperature=297.25, WindSpeed= 0, WindDirection="N",  Humidity="47" }},
        };
    }
}
