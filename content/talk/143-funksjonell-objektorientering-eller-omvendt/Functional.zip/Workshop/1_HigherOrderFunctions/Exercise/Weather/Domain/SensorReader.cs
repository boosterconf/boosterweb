﻿using System;

namespace Weather.Domain
{
    public interface ISensorReader { }
    public class SensorReader<T>: ISensorReader
    {
        public SensorReader(Func<string, T> execute)
        {
            Execute = execute;
        }
        public Func<string, T> Execute { get; }
    }
}
