﻿namespace Weather.Domain
{
    public class Measurements
    {
        public Measurements()
        {
        }

        public string Timestamp { get; set; }
        public int CloudCover { get; set; }
    }
}
