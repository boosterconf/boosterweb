﻿using System;
using System.Runtime.InteropServices;
using Weather.Domain;

namespace Weather.Logging
{
    internal class DbLogger
    {
        public DbLogger()
        {
            AllocConsole();
            Console.WriteLine("Db Console Running");
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool AllocConsole();

        private LogRecord CreateLogRecord(Measurements values)
        {
            return new LogRecord
            {
                StationId = "42",
                Owner = "Knut",
                Place = "Bergen",
                Position = "60°23'52.0\"N 5°19'20.7\"E",
                TimeStamp = values.Timestamp,
                Clouds = values.CloudCover,
            };
        }

        internal void LogCurrentValues(Measurements values)
        {
            var logRec = CreateLogRecord(values);
            // Submit LogRecord to database...
            Console.WriteLine(
                $"StationId: {logRec.StationId}, " +
                $"Owner: {logRec.Owner}, " +
                $"Place: {logRec.Place}, " +
                $"Position: {logRec.Position}, " +
                $"Time: {logRec.TimeStamp}, " +
                $"Clouds: {logRec.Clouds}okt, "
            );
            Console.WriteLine();
        }
    }

    public class LogRecord
    {
        public string StationId { get; set; }
        public string Owner { get; set; }
        public string Place { get; set; }
        public string Position { get; set; }
        public string TimeStamp { get; set; }
        public int Clouds { get; set; }
    }
}