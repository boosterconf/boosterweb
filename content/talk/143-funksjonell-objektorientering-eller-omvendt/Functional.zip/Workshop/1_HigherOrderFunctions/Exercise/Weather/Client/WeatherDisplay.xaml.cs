﻿using System.Windows;

namespace Weather.Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class WeatherDisplay : Window
    {
        public WeatherDisplay()
        {
            InitializeComponent();
            DataContext = new WeatherDisplayVm();
        }
    }
}
