﻿using System;
using System.Collections.Generic;

namespace Weather.Sensors
{
    public interface ISensor { }
    public interface ISensor<T>: ISensor
    {
        public Func<string, T> InitSensor(Func<IEnumerable<WeatherData>, Dictionary<string, T>> setup);
    }
}
