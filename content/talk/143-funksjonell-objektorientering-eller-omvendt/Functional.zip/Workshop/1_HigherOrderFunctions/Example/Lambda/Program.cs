﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

List<int> numbers = new List<int> { 42, 1, 2, 3 };
int divisor = 0;
IEnumerable<int> deferred = numbers.Select(p => p / divisor);  // Divison by zero?? No, not yet...

// Division by zero happens next, when "materializing" the result
Debug.WriteLine($"Divided by {divisor}: {deferred.First()}"); // Ok, comment out this line after the crash

// Next, reassigning the divisor... after the lambda function is defined
divisor = 1;
Debug.WriteLine($"Divided by {divisor}: {deferred.First()}"); 

// And do it again...
divisor = 2;
Debug.WriteLine($"Divided by {divisor}: {deferred.First()}");

// Reassigning the list object: The lambda still uses the old list!
numbers = new List<int> { 666, 1, 2, 3, 4, 5 };  

// What about this way...? Yes, there we are
//numbers.Clear();
//numbers.AddRange(new List<int>{ 666, 1, 2, 3, 4, 5 });
            
Debug.WriteLine($"Divided by {divisor}: {deferred.First()}");
Debug.WriteLine($"Number of elements: {deferred.Count()}");
