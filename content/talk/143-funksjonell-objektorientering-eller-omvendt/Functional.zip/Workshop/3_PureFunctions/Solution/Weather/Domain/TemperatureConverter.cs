﻿using System;

namespace Weather.Domain
{
    public static class TemperatureConverter
    {
        public static Func<double, double> ToKelvin { get; } = t => t;
        public static Func<double, double> ToCelsius { get; } = t => t - 273.15;
        public static Func<double, double> ToFarenheit { get; } = t => (t - 273.15) * 1.8 + 32.0;

        public static double ConvertTemperature(this double kelvin, Func<double, double> convert) {
            return convert(kelvin);
        }
    }
}
