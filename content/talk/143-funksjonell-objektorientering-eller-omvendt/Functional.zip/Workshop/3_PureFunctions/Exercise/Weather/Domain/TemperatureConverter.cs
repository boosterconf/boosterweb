﻿namespace Weather.Domain
{
    public class TemperatureConverter
    {
        private double factor = 1.0;
        public double Bias { get; set; } = 0.0;
        public double Factor { get { return factor; } set {
                if (factor == 1.8) Bias2 = 32.0;
                factor = value; 
            } 
        }
        public double Convert(double kelvin)
        {
            return (kelvin + Bias) * Factor + Bias2;
        }
        public static double Bias2 { get; set; } = 0.0;
    }
}
