﻿using System;
using System.Collections.Generic;

namespace Weather.Sensors
{
    public class Thermometer : ISensor<double>
    {
        // A thermometer masures temperature (heat, or lack of such).

        // Different temperature scales are in use. The termometer we have aquired, is reporting absolute temperature
        // (degrees Kelvin) which means 0 degrees is at the absolute zero.
        // Other, more practical scales in use, are Celsius and Farenheit. Conversion formulas are:
        // C = K + 273.15, F = (K + 273.15) * 9/5 + 32

        private Dictionary<string, double> temperature = new Dictionary<string, double>();

        public Func<string, double> InitSensor(Func<IEnumerable<WeatherData>, Dictionary<string, double>> setup)
        {
            temperature = setup(WeatherData.SensorValues);
            return s => temperature[s];
        }
    }
}
