﻿using Prism.Commands;
using PropertyChanged;
using Weather.Domain;

namespace Weather.Client
{
    [AddINotifyPropertyChangedInterface]
    public class WeatherDisplayVm
    {
        private WeatherStationService Service = new WeatherStationService();
        private TemperatureConverter temperatureConverter = new TemperatureConverter();
        public DelegateCommand StartCommand { get; set; }
        public DelegateCommand UpdateCommand { get; set; }
        public DelegateCommand SetKelvinCommand { get; set; }
        public DelegateCommand SetCelsiusCommand { get; set; }
        public DelegateCommand SetFarenheitCommand { get; set; }
        public Measurements CurrentValues { get; set; }
        public double Temperature => temperatureConverter.Convert(CurrentValues?.Temperature??0.0);
        [AlsoNotifyFor(nameof(Temperature))]
        public string TemperatureScale { get; set; } = "°K";
        public bool ServiceRunning { get; set; }
        public WeatherDisplayVm()
        {
            StartCommand = new DelegateCommand(StartService, () => !ServiceRunning).ObservesProperty(() => ServiceRunning);
            UpdateCommand = new DelegateCommand(() => Update(), () => ServiceRunning).ObservesProperty(() => ServiceRunning);
            SetKelvinCommand = new DelegateCommand(SetKelvin);
            SetCelsiusCommand = new DelegateCommand(SetCelsius);
            SetFarenheitCommand = new DelegateCommand(SetFarenheit);
        }
        private void SetKelvin()
        {
            temperatureConverter.Bias = 0.0;
            temperatureConverter.Factor = 1.0;
            TemperatureScale = "°K";
        }

        private void SetCelsius()
        {
            temperatureConverter.Bias = -273.15;
            temperatureConverter.Factor = 1.0;
            TemperatureScale = "°C";
        }

        private void SetFarenheit()
        {
            temperatureConverter.Bias = -273.15;
            temperatureConverter.Factor = 1.8;
            TemperatureScale = "°F";
        }

        private void StartService()
        {
            Service.StartUp();
            Update();
        }

        private void Update()
        {
            CurrentValues = null;
            Service.UpdateReadings();
            UpdateClient();
        }

        private void UpdateClient()
        {
            CurrentValues = Service.CurrentValues;
            ServiceRunning = Service.Running;
        }
    }
}
