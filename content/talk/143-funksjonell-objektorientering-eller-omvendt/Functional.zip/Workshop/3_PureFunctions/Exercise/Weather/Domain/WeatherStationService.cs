﻿using System.Collections.Generic;
using System.Linq;
using Weather.Logging;
using Weather.Sensors;

namespace Weather.Domain
{
    public class WeatherStationService
    {
        public Measurements CurrentValues { get; set; }
        private ConnectedSensors Sensors = new ConnectedSensors();
        IEnumerator<string> Timestapms = WeatherData.SensorValues.Select(v=>v.Timestamp).ToList().GetEnumerator();
        DbLogger DbLogger = new DbLogger();
        public bool Running { get; set; } = false;
        public Dictionary<ISensor, ISensorReader> SensorReaders = new Dictionary<ISensor, ISensorReader>();
        public void StartUp()
        {
            Running = true;
            Timestapms.Reset();
            SensorReaders[Sensors.CloudCoverRecorder] = new SensorReader<int>(Sensors.CloudCoverRecorder
                .InitSensor(w => w.ToDictionary(w => w.Timestamp, w => w.CloudCover)));
            SensorReaders[Sensors.RainGauge] = new SensorReader<double>(Sensors.RainGauge
                .InitSensor(w => w.ToDictionary(w => w.Timestamp, w => w.Rainfall)));
            SensorReaders[Sensors.Thermometer]=new SensorReader<double>(Sensors.Thermometer
                .InitSensor(w => w.ToDictionary(w => w.Timestamp, w => w.Temperature)));
        }
        public void UpdateReadings()
        {
            if (Timestapms.MoveNext()) 
            { 
                CurrentValues = ReadSensors(Timestapms.Current);
                DbLogger.LogCurrentValues(CurrentValues);
            }
            else { Running = false; }
        }

        private Measurements ReadSensors(string timestamp)
        {
            return new Measurements.Builder()
				.At(timestamp)
				.WithCloudCover(((SensorReader<int>)SensorReaders[Sensors.CloudCoverRecorder]).Execute(timestamp))
				.WithRainfall(((SensorReader<double>)SensorReaders[Sensors.RainGauge]).Execute(timestamp))
                .WithTemperature(((SensorReader<double>)SensorReaders[Sensors.Thermometer]).Execute(timestamp))
                .Build();
        }
    }
}
