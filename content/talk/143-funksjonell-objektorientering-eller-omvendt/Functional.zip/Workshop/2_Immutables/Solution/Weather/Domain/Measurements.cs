﻿namespace Weather.Domain
{
    public class Measurements
    {
        public Measurements(string timestamp, int cloudCover, double rainfall)
        {
            Timestamp = timestamp;
            CloudCover = cloudCover;
            Rainfall = rainfall;
        }

        public string Timestamp { get; }
        public int CloudCover { get; }
        public double Rainfall { get; }

        public class Builder
        {
            private string Timestamp { get; set; }
            private int CloudCover { get; set; }
            private double Rainfall { get; set; }

            public Builder At(string timestamp)
            {
                Timestamp = timestamp;
                return this;
            }
            public Builder WithCloudCover(int cloudCover)
            {
                CloudCover = cloudCover;
                return this;
            }
            public Builder WithRainfall(double rainfall)
            {
                Rainfall = rainfall;
                return this;
            }
            public Measurements Build()
            {
                return new Measurements(Timestamp, CloudCover, Rainfall);
            }
        }
    }
}
