﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Weather.Logging;
using Weather.Sensors;

namespace Weather.Domain
{
    public class WeatherStationService
    {
        public Measurements CurrentValues { get; set; }
        private ConnectedSensors Sensors = new ConnectedSensors();
        IEnumerator<string> Timestapms = WeatherData.SensorValues.Select(v=>v.Timestamp).ToList().GetEnumerator();
        DbLogger DbLogger = new DbLogger();
        public bool Running { get; set; } = false;
        public Dictionary<ISensor, ISensorReader> SensorReaders = new Dictionary<ISensor, ISensorReader>();
        public void StartUp()
        {
            Running = true;
            Timestapms.Reset();
            SensorReaders[Sensors.CloudCoverRecorder] = new SensorReader<int>(Sensors.CloudCoverRecorder
                .InitSensor(w => w.ToDictionary(w => w.Timestamp, w => w.CloudCover)));
            SensorReaders[Sensors.RainGauge] = new SensorReader<double>(Sensors.RainGauge
                .InitSensor(w => w.ToDictionary(w => w.Timestamp, w => w.Rainfall)));
        }
        public void UpdateReadings(bool delay=false)
        {
            if (Timestapms.MoveNext()) 
            { 
                CurrentValues = ReadSensors(Timestapms.Current, delay?200:0);
                DbLogger.LogCurrentValues(CurrentValues);
            }
            else { Running = false; }
        }

        private Measurements ReadSensors(string timestamp, int delay = 0)
        {
            Measurements.Builder builder = new Measurements.Builder()
				.At(timestamp)
				.WithCloudCover(((SensorReader<int>)SensorReaders[Sensors.CloudCoverRecorder]).Execute(timestamp));
            // This is to force a race condition:
            Thread.Sleep(delay);
            return builder
				.WithRainfall(((SensorReader<double>)SensorReaders[Sensors.RainGauge]).Execute(timestamp))
				.Build();
        }
    }
}
