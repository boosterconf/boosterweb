﻿using Weather.Sensors;

namespace Weather.Domain
{
    public class ConnectedSensors
    {
        public ISensor<int> CloudCoverRecorder { get; } = new CloudCoverRecorder();
        public ISensor<double> RainGauge { get; } = new RainGauge();
    }
}
