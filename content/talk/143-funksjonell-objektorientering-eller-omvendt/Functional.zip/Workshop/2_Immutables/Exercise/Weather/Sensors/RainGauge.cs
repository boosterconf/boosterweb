﻿using System;
using System.Collections.Generic;

namespace Weather.Sensors
{
    // The Rain Gauge measures the intensity of rainfall, and reports this extrapolated to a per-hour value.

    // Rainfall is measured in mm/h.
    public class RainGauge : ISensor<double>
    {
        private Dictionary<string, double> rainfall = new Dictionary<string, double>();

        public Func<string, double> InitSensor(Func<IEnumerable<WeatherData>, Dictionary<string, double>> setup)
        {
            rainfall = setup(WeatherData.SensorValues);
            return s => rainfall[s];
        }
    }
}
