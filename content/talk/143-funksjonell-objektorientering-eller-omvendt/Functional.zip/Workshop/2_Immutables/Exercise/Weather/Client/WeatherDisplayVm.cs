﻿using Prism.Commands;
using PropertyChanged;
using System.Threading;
using Weather.Domain;

namespace Weather.Client
{
    [AddINotifyPropertyChangedInterface]
    public class WeatherDisplayVm
    {
        private WeatherStationService Service = new WeatherStationService();
        public DelegateCommand StartCommand { get; set; }
        public DelegateCommand UpdateCommand { get; set; }
        public Measurements CurrentValues { get; set; }
        public bool ServiceRunning { get; set; }
        public WeatherDisplayVm()
        {
            StartCommand = new DelegateCommand(StartService, () => !ServiceRunning).ObservesProperty(() => ServiceRunning);
            UpdateCommand = new DelegateCommand(() => Update(), () => ServiceRunning).ObservesProperty(() => ServiceRunning);
        }

        private void StartService()
        {
            Service.StartUp();
            Update(false);
        }

        private void Update(bool delay = true)
        {
            CurrentValues = null;
            var t = new Thread(() => Service.UpdateReadings(delay));
            t.Start();
            Thread.Sleep(100);
            UpdateClient();
        }

        private void UpdateClient()
        {
            CurrentValues = Service.CurrentValues;
            ServiceRunning = Service.Running;
        }
    }
}
