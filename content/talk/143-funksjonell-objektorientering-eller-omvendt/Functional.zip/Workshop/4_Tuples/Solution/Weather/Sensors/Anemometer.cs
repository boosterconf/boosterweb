﻿using System;
using System.Collections.Generic;

namespace Weather.Sensors
{
    // The anemometer measures wind. It reports two values: Wind speed and wind direction.

    // Wind speed is measured in m/s. Direction is reported as a string, indicating the nearest 8ht of the compass:
    // N, NE, E, SE, S, SW, W, NW.

    // The current implementation does not comply to the ISenor interface...

    public class Anemometer: ISensor<(int speed, string direction)>
    {
        private Dictionary<string, (int, string)> wind = new Dictionary<string, (int, string)>();

        public Func<string, (int speed, string direction)> InitSensor(Func<IEnumerable<WeatherData>, Dictionary<string, (int speed, string direction)>> setup)
        {
            wind = setup(WeatherData.SensorValues);
            return s => wind[s];
        }
    }
}
