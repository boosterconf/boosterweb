﻿using System.Linq;

namespace Weather.Sensors
{
    // The anemometer measures wind. It reports two values: Wind speed and wind direction.

    // Wind speed is measured in m/s. Direction is reported as a string, indicating the nearest 8ht of the compass:
    // N, NE, E, SE, S, SW, W, NW.

    // The current implementation does not comply to the ISenor interface...

    public class Anemometer
    {
        public virtual int ReadSpeed(string time)
        {
            return WeatherData.SensorValues.Single(v =>v.Timestamp==time).WindSpeed;
        }
        public virtual string ReadDirection(string time)
        {
            return WeatherData.SensorValues.Single(v => v.Timestamp == time).WindDirection;
        }
    }
}
