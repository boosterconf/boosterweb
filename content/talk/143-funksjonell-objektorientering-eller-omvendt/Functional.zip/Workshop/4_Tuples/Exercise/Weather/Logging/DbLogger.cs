﻿using System;
using System.Runtime.InteropServices;
using Weather.Domain;

namespace Weather.Logging
{
    internal class DbLogger
    {
        public DbLogger()
        {
            AllocConsole(); 
            Console.WriteLine("Db Console Running");
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool AllocConsole();

        private LogRecord logRecord = new LogRecord
        {
            StationId = "42",
            Owner = "Knut",
            Place = "Bergen",
            Position = "60°23'52.0\"N 5°19'20.7\"E",
        };
        private LogRecord CreateLogRecord(Measurements values)
        {
            return logRecord with {
                TimeStamp = values.Timestamp,
                Clouds = values.CloudCover,
                Rain = values.Rainfall,
                Temperature = values.Temperature.ConvertTemperature(TemperatureConverter.ToFarenheit),
                WindSpeed = values.WindSpeed,
                WindDirection = values.WindDirection,
            };
        }

        internal void LogCurrentValues(Measurements values)
        {
            var logRec = CreateLogRecord(values);
            // Submit LogRecord to database...
            Console.WriteLine( //logRec);
                $"StationId: {logRec.StationId}, " +
                $"Owner: {logRec.Owner}, " +
                $"Place: {logRec.Place}, " +
                $"Position: {logRec.Position}, " +
                $"Time: {logRec.TimeStamp}, " +
                $"Clouds: {logRec.Clouds}okt, " +
                $"Rain: {logRec.Rain:N1}mm/h, " +
                $"Temperature: {logRec.Temperature:N1}°K, " +
                $"Wind Speed: {logRec.WindSpeed}m/s, " +
                $"Wind Dir: {logRec.WindDirection}"
            );
            Console.WriteLine();
        }
    }

    public record LogRecord
    {
        public string StationId { get; init; }
        public string Owner { get; init; }
        public string Place { get; init; }
        public string Position { get; init; }
        public string TimeStamp { get; init; }
        public int Clouds { get; init; }
        public double Rain { get; init; }
        public double Temperature { get; init; }
        public int WindSpeed { get; init; }
        public string WindDirection { get; init; }
    }
}