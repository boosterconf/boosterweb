﻿using Prism.Commands;
using PropertyChanged;
using System;
using Weather.Domain;

namespace Weather.Client
{
    [AddINotifyPropertyChangedInterface]
    public class WeatherDisplayVm
    {
        private WeatherStationService Service = new WeatherStationService();
        private Func<double, double> selectedTarget = TemperatureConverter.ToKelvin;
        public DelegateCommand StartCommand { get; set; }
        public DelegateCommand UpdateCommand { get; set; }
        public DelegateCommand SetKelvinCommand { get; set; }
        public DelegateCommand SetCelsiusCommand { get; set; }
        public DelegateCommand SetFarenheitCommand { get; set; }
        public Measurements CurrentValues { get; set; }
        public double Temperature => CurrentValues?.Temperature.ConvertTemperature(selectedTarget)??0.0;
        [AlsoNotifyFor(nameof(Temperature))]
        public string TemperatureScale { get; set; } = "°K";
        public int WindSpeed => CurrentValues?.WindSpeed??0;
        public string WindDirection => CurrentValues?.WindDirection;
        public bool ServiceRunning { get; set; }
        public WeatherDisplayVm()
        {
            StartCommand = new DelegateCommand(StartService, () => !ServiceRunning).ObservesProperty(() => ServiceRunning);
            UpdateCommand = new DelegateCommand(() => Update(), () => ServiceRunning).ObservesProperty(() => ServiceRunning);
            SetKelvinCommand = new DelegateCommand(SetKelvin);
            SetCelsiusCommand = new DelegateCommand(SetCelsius);
            SetFarenheitCommand = new DelegateCommand(SetFarenheit);
        }

        private void SetKelvin()
        {
            selectedTarget = TemperatureConverter.ToKelvin;
            TemperatureScale = "°K";
        }

        private void SetCelsius()
        {
            selectedTarget = TemperatureConverter.ToCelsius;
            TemperatureScale = "°C";
        }

        private void SetFarenheit()
        {
            selectedTarget = TemperatureConverter.ToFarenheit;
            TemperatureScale = "°F";
        }

        private void StartService()
        {
            Service.StartUp();
            Update();
        }

        private void Update()
        {
            CurrentValues = null;
            Service.UpdateReadings();
            UpdateClient();
        }

        private void UpdateClient()
        {
            CurrentValues = Service.CurrentValues;
            ServiceRunning = Service.Running;
        }
    }
}
