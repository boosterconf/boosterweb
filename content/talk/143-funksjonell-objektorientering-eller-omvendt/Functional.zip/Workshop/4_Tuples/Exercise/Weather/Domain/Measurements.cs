﻿namespace Weather.Domain
{
    public class Measurements
    {
        public Measurements(string timestamp, int cloudCover, double rainfall, double temperature, int windSpeed, string windDirection)
        {
            Timestamp = timestamp;
            CloudCover = cloudCover;
            Rainfall = rainfall;
            Temperature = temperature;
            WindSpeed = windSpeed;
            WindDirection = windDirection;
        }

        public string Timestamp { get; }
        public int CloudCover { get; }
        public double Rainfall { get; }
        public double Temperature { get; }
        public int WindSpeed { get; }
        public string WindDirection { get; }

        public class Builder
        {
            private string Timestamp { get; set; }
            private int CloudCover { get; set; }
            private double Rainfall { get; set; }
            private double Temperature { get; set; }
            private int WindSpeed { get; set; }
            private string WindDirection { get; set; }

            public Builder At(string timestamp)
            {
                Timestamp = timestamp;
                return this;
            }
            public Builder WithCloudCover(int cloudCover)
            {
                CloudCover = cloudCover;
                return this;
            }
            public Builder WithRainfall(double rainfall)
            {
                Rainfall = rainfall;
                return this;
            }
            public Builder WithTemperature(double temperature)
            {
                Temperature = temperature;
                return this;
            }
            public Builder WithWind(int speed, string direction)
            {
                WindSpeed = speed;
                WindDirection = direction;
                return this;
            }
            public Measurements Build()
            {
                return new Measurements(Timestamp, CloudCover, Rainfall, Temperature, WindSpeed, WindDirection);
            }
        }
    }
}
