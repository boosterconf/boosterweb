﻿using Weather.Sensors;

namespace Weather.Domain
{
    public class ConnectedSensors
    {
        public ISensor<int> CloudCoverRecorder { get; } = new CloudCoverRecorder();
        public ISensor<double> RainGauge { get; } = new RainGauge();
        public ISensor<double> Thermometer { get; } = new Thermometer();
        public ISensor<(int, string)> Anemometer { get; } = new Anemometer();
        public ISensor<string> Hygrometer { get; } = new Hygrometer();
    }
}
