﻿using System;
using System.Collections.Generic;

namespace Weather.Sensors
{
    public class Hygrometer : ISensor<string>
    {
        // The hygrometer measures air humidity, which is expressed in % (0 - 100).
        //
        // Unfortunately, we used most of our budget on the previous sensors, forcing us to buy a really inexpensive hygrometer.
        // So, we have some challenges with quality.
        // First, this unit reports the humidity as a umeric string, not an int. For reporting to the db (and eventually other clients),
        // we will need to convert it to int, which is the standard format for reporting humidity.
        // Further, it has a very narrow measurment span: from about 40% to 70%. Outside these values, it reports "ERR".
        // Perhaps there are other undocumented features as well?

        private Dictionary<string, string> humidity = new Dictionary<string, string>();

        public Func<string, string> InitSensor(Func<IEnumerable<WeatherData>, Dictionary<string, string>> setup)
        {
            humidity = setup(WeatherData.SensorValues);
            return s => humidity[s];
        }
    }
}
