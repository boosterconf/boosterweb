﻿using System.Globalization;

namespace Weather
{
    public static class HumidityConverter
    {
        public static int? ConvertHumidity(this string humidity)
        {
            if (humidity is not null)
            {
                return int.Parse(humidity);
                //if (int.TryParse(humidity, out int h)) return h;
            }
            return null;
        }

    }
}
