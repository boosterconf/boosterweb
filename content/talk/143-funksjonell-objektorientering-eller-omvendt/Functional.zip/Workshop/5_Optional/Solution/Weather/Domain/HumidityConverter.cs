﻿using Optional;

namespace Weather.Domain
{
    public static class HumidityConverter
    {
        public static Option<int> ToIntOption(this string s)
        {
            bool success = int.TryParse(s, out int i);
            return i.SomeWhen(i => success);
        }

        public static Option<int> ConvertHumidity(this string strHumidity)
        {
            return strHumidity.SomeNotNull().Map(s => s.ToIntOption()).FlatMap(i => i);
        }
    }
}
